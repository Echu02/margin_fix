=============================
-
Margin fix script
-
=============================

What the code does?

This code is done to fix the margins of one label. If for some reason it is greater than 1920 x 1080 or negative, it will refresh it to the minimum and maximum margins (x <= 1920, y <= 1080 // x >= 0, y >= 0)

Scripted by: Lyron and Ezequiel