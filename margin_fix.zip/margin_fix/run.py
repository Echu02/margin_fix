from pathlib import Path
import hashlib

source_dir = Path(r'E:\Scripts\margin_fix\labels')
files = list(x for x in source_dir.iterdir() if x.is_file())


for i in range(len(files)):
    file = Path(files[i])
    outfile = str(i) + file.suffix
    with open(file) as fReader, open(outfile, "w") as fOut:
        for line in fReader:
            line_split = line.split()
            x1 = int(line_split[4])
            y1 = int(line_split[5])
            x2 = int(line_split[6])
            y2 = int(line_split[7])

            if x1 < 0:
                x1 = 0
                line_split[4] = x1
            if y1 < 0:
                y1 = 0
                line_split[5] = y1
            if x2 > 1920:
                x2 = 1920
                line_split[6] = x2
            if y2 > 1080:
                y2 = 1080
                line_split[7] = y2
            new_line = ' '.join([str(elem) for elem in line_split])
            new_line = new_line + '\n'
            fOut.write(new_line)
